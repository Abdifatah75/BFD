
import streamlit as st
import pandas as pd
from datetime import datetime, date
from dateutil.relativedelta import relativedelta
import io
from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
from openpyxl.utils import get_column_letter
import os

st.set_page_config(page_title="BFD – Wochenabrechnung", page_icon="💼", layout="wide")

DATA_PATH = "data/entries.csv"

CATS = ["Einnahme", "Ausgabe"]
UNTER = [
    "Umsatz", "Tipp", "Privatfahrten", "Uber Überweisung", "Uber Barzahlungen",
    "Tanken", "Sozial Abgabe", "Sonstiges Einnahme", "Sonstiges Ausgabe"
]
ZAHL = ["Uber-Überweisung", "Uber-App", "Bar/Privat", "Karte", "Sonstiges"]

def ensure_data():
    if not os.path.exists(DATA_PATH):
        df = pd.DataFrame(columns=[
            "Datum","Kategorie","Unterkategorie","Betrag","Zahlungsart",
            "Woche","Monat","Jahr"
        ])
        df.to_csv(DATA_PATH, index=False)
    return pd.read_csv(DATA_PATH, parse_dates=["Datum"])

def save_data(df):
    df.to_csv(DATA_PATH, index=False)

def add_entry(row):
    df = ensure_data()
    df = pd.concat([df, pd.DataFrame([row])], ignore_index=True)
    save_data(df)

def week_of(d):
    # ISO week (Mon-Sun) to match EU work weeks
    return d.isocalendar()[1]

def month_of(d):
    return d.month

def year_of(d):
    return d.year

def kpi_card(title, value):
    st.metric(title, f"{value:,.2f} €")

def weekly_report(df, month, year):
    # Filter to month/year
    dff = df[(df["Monat"]==month) & (df["Jahr"]==year)].copy()
    if dff.empty:
        return pd.DataFrame(), {}

    # Build week list present in the data (1..53 but we'll show sorted unique)
    weeks = sorted(dff["Woche"].dropna().astype(int).unique().tolist()) or [1,2,3,4,5]
    
    # Helper sums
    def sumf(week, kat=None, unter=None):
        q = (dff["Woche"]==week)
        if kat: q &= (dff["Kategorie"]==kat)
        if unter: q &= (dff["Unterkategorie"]==unter)
        return float(dff.loc[q, "Betrag"].sum()) if not dff.loc[q].empty else 0.0

    rows = []
    totals = {"Umsatz_ohne":0,"Tipp":0,"Umsatz_mit":0,"Fahrer40":0,"Fahrer_mit":0,"Bar":0,"Tanken":0,"Sozial":0,"Ausgaben":0,
              "Privat":0,"Ueberw":0,"BarUber":0}
    for w in weeks:
        umsatz_ohne = sumf(w,"Einnahme","Umsatz")
        tipp = sumf(w,"Einnahme","Tipp")
        umsatz_mit = umsatz_ohne + tipp
        fahrer40 = 0.4 * umsatz_ohne
        fahrer_mit = fahrer40 + tipp
        bar = sumf(w,None,"Barzahlungen") + sumf(w,None,"Uber Barzahlungen")  # tolerate both labels
        tanken = sumf(w,"Ausgabe","Tanken")
        sozial = sumf(w,"Ausgabe","Sozial Abgabe")
        ausgaben = tanken + sozial

        privat = sumf(w,"Einnahme","Privatfahrten")
        ueberw = sumf(w,"Einnahme","Uber Überweisung")
        bar_uber = sumf(w,"Einnahme","Uber Barzahlungen")

        rows.append({
            "Woche": w,
            "Umsatz ohne Tipp": umsatz_ohne,
            "Tipp": tipp,
            "Umsatz mit Tipp": umsatz_mit,
            "Anteil Fahrer 40% ohne Tipp": fahrer40,
            "Anteil Fahrer mit Tipp": fahrer_mit,
            "Barzahlung": bar,
            "Tanken": tanken,
            "Sozial Abgabe": sozial,
            "Ausgaben gesamt": ausgaben,
            "Privatfahrten": privat,
            "Uber Überweisung": ueberw,
            "Uber Barzahlungen": bar_uber,
        })
        totals["Umsatz_ohne"] += umsatz_ohne
        totals["Tipp"] += tipp
        totals["Umsatz_mit"] += umsatz_mit
        totals["Fahrer40"] += fahrer40
        totals["Fahrer_mit"] += fahrer_mit
        totals["Bar"] += bar
        totals["Tanken"] += tanken
        totals["Sozial"] += sozial
        totals["Ausgaben"] += ausgaben
        totals["Privat"] += privat
        totals["Ueberw"] += ueberw
        totals["BarUber"] += bar_uber

    rep = pd.DataFrame(rows).set_index("Woche")
    # Bottom summary like Excel
    verdienen = totals["Privat"] + totals["Ueberw"] + totals["BarUber"]
    verdient_fahrer = totals["Fahrer_mit"]
    bezahlt_bar = totals["Bar"]
    ich_bekomme_noch = verdient_fahrer - totals["Ueberw"] - bezahlt_bar - totals["Ausgaben"]

    bottom = {
        "Schuld": None,
        "Verdienst (Fahrer mit Tipp)": verdient_fahrer,
        "Bezahlt Bar": bezahlt_bar,
        "Ich bekomme noch": ich_bekomme_noch,
        "Verdienen Total": verdienen,
    }
    return rep, bottom

def export_excel(rep_df, bottom, month, year):
    # Build an Excel like the PLUS template
    wb = Workbook()
    ws = wb.active
    ws.title = "Abrechnung"
    title_font = Font(bold=True, size=14)
    bold = Font(bold=True)
    center = Alignment(horizontal="center", vertical="center")
    thin = Side(style="thin", color="000000")
    border_all = Border(left=thin, right=thin, top=thin, bottom=thin)
    header_fill = PatternFill(start_color="DDDDDD", end_color="DDDDDD", fill_type="solid")

    ws.merge_cells("A1:G1")
    ws["A1"] = f"Bensheimer Fahrdienst – Monatsabrechnung {month:02d}/{year}"
    ws["A1"].font = title_font
    ws["A1"].alignment = center

    headers = ["", "1. Woche", "2. Woche", "3. Woche", "4. Woche", "5. Woche", "Total"]
    for i,h in enumerate(headers, start=1):
        ws.cell(5,i).value = h
        c = ws.cell(5,i)
        c.font = bold; c.alignment = center; c.fill = header_fill

    labels = [
        "Umsatz mit Tipp", "","Tipp","", "Umsatz ohne Tipp","",
        "Anteil Fahrer 40% ohne Tipp","", "Anteil Fahrer mit Tipp","",
        "Barzahlung","", "Tanken (Ausgabe)","", "Sozial Abgabe (Ausgabe)","",
        "Ausgaben gesamt",""
    ]

    start_row = 6
    for idx, lab in enumerate(labels):
        r = start_row + idx
        ws.cell(r,1).value = lab
        for c in range(2,7):
            ws.cell(r,c).number_format = "#,##0.00 €"
        ws.cell(r,7).number_format = "#,##0.00 €"

    # Fill weekly columns up to 5 weeks
    def fill_row(row_label, series_label):
        r = None
        # find row index by label
        for i in range(start_row, start_row+len(labels)):
            if ws.cell(i,1).value == row_label:
                r = i; break
        if r is None: return
        # write per-week and total
        total = 0.0
        for i,w in enumerate([1,2,3,4,5], start=2):
            val = float(rep_df.loc[w, series_label]) if (w in rep_df.index and series_label in rep_df.columns) else 0.0
            ws.cell(r,i).value = val
            total += val
        ws.cell(r,7).value = total

    fill_row("Umsatz mit Tipp","Umsatz mit Tipp")
    fill_row("Tipp","Tipp")
    fill_row("Umsatz ohne Tipp","Umsatz ohne Tipp")
    fill_row("Anteil Fahrer 40% ohne Tipp","Anteil Fahrer 40% ohne Tipp")
    fill_row("Anteil Fahrer mit Tipp","Anteil Fahrer mit Tipp")
    fill_row("Barzahlung","Barzahlung")
    fill_row("Tanken (Ausgabe)","Tanken")
    fill_row("Sozial Abgabe (Ausgabe)","Sozial Abgabe")
    fill_row("Ausgaben gesamt","Ausgaben gesamt")

    # Bottom block
    r0 = start_row + len(labels) + 2
    ws.cell(r0,1).value = "Verdienen"
    ws.cell(r0,1).font = title_font
    r = r0 + 1
    ws.cell(r,1).value = "Privatfahrten"; ws.cell(r,7).value = float(rep_df["Privatfahrten"].sum()) if "Privatfahrten" in rep_df.columns else 0.0; r+=1
    ws.cell(r,1).value = "Uber (Überweisung)"; ws.cell(r,7).value = float(rep_df["Uber Überweisung"].sum()) if "Uber Überweisung" in rep_df.columns else 0.0; r+=1
    ws.cell(r,1).value = "Uber (Barzahlungen)"; ws.cell(r,7).value = float(rep_df["Uber Barzahlungen"].sum()) if "Uber Barzahlungen" in rep_df.columns else 0.0; r+=1
    ws.cell(r,1).value = "Total"; ws.cell(r,7).value = float(rep_df["Privatfahrten"].sum() + rep_df["Uber Überweisung"].sum() + rep_df["Uber Barzahlungen"].sum()) if {"Privatfahrten","Uber Überweisung","Uber Barzahlungen"}.issubset(set(rep_df.columns)) else 0.0; r+=1
    ws.cell(r,1).value = "Schuld"; r+=1
    ws.cell(r,1).value = "Verdienst (Fahrer mit Tipp)"; ws.cell(r,7).value = float(bottom.get("Verdienst (Fahrer mit Tipp)",0.0)); r+=1
    ws.cell(r,1).value = "Bezahlt Bar"; ws.cell(r,7).value = float(bottom.get("Bezahlt Bar",0.0)); r+=1
    ws.cell(r,1).value = "Ich bekomme noch"; ws.cell(r,7).value = float(bottom.get("Ich bekomme noch",0.0)); 

    # number formats
    for rr in range(start_row, r+1):
        ws.cell(rr,7).number_format = "#,##0.00 €"

    # Column widths
    widths = [34, 14, 14, 14, 14, 14, 16]
    for i,w in enumerate(widths, start=1):
        ws.column_dimensions[get_column_letter(i)].width = w

    bio = io.BytesIO()
    wb.save(bio)
    bio.seek(0)
    return bio

st.title("💼 Bensheimer Fahrdienst – Wochenabrechnung")
st.caption("Sida Excel-kaaga oo kale, usbuuc-usbuuc. Ku qor xogta, kadib soo saar Excel.")

# Data entry
with st.form("entry"):
    c1,c2,c3,c4,c5 = st.columns(5)
    d = c1.date_input("Datum", value=date.today())
    kat = c2.selectbox("Kategorie", CATS, index=0)
    unter = c3.selectbox("Unterkategorie", UNTER, index=0)
    betrag = c4.number_input("Betrag (€)", min_value=-100000.0, max_value=100000.0, value=0.0, step=1.0, format="%.2f")
    zahl = c5.selectbox("Zahlungsart", ZAHL, index=0)
    submitted = st.form_submit_button("➕ Add Entry")
    if submitted:
        w = week_of(pd.to_datetime(d))
        m = month_of(pd.to_datetime(d))
        y = year_of(pd.to_datetime(d))
        add_entry({
            "Datum": pd.to_datetime(d),
            "Kategorie": kat,
            "Unterkategorie": unter,
            "Betrag": float(betrag),
            "Zahlungsart": zahl,
            "Woche": int(w),
            "Monat": int(m),
            "Jahr": int(y),
        })
        st.success("Entry added.")

df = ensure_data()
st.subheader("📒 Xogtaada (Data)")
st.dataframe(df.sort_values("Datum", ascending=False), use_container_width=True)

# Backup / Restore
c1,c2 = st.columns(2)
with c1:
    st.download_button("⬇️ Download Backup (CSV)", data=df.to_csv(index=False).encode("utf-8"), file_name="entries_backup.csv", mime="text/csv")
with c2:
    up = st.file_uploader("⬆️ Upload Restore (CSV)", type=["csv"])
    if up is not None:
        newdf = pd.read_csv(up, parse_dates=["Datum"])
        save_data(newdf)
        st.success("Backup restored. Reload page to see updates.")

# Report filters
st.subheader("📊 Report – Monats- und Wochenübersicht")
rc1,rc2,rc3 = st.columns(3)
month = rc1.number_input("Monat (1-12)", min_value=1, max_value=12, value=datetime.now().month, step=1)
year = rc2.number_input("Jahr", min_value=2000, max_value=2100, value=datetime.now().year, step=1)

rep, bottom = weekly_report(df, month, year)
if rep.empty:
    st.info("Xog ma jirto bishaas. Geli entries ka dib mar kale fiiri.")
else:
    st.dataframe(rep, use_container_width=True)
    kc1,kc2,kc3,kc4,kc5 = st.columns(5)
    kc1.metric("Umsatz ohne Tipp (Total)", f"{rep['Umsatz ohne Tipp'].sum():,.2f} €")
    kc2.metric("Tipp (Total)", f"{rep['Tipp'].sum():,.2f} €")
    kc3.metric("Fahrer 40% ohne Tipp (Total)", f"{rep['Anteil Fahrer 40% ohne Tipp'].sum():,.2f} €")
    kc4.metric("Ausgaben gesamt (Total)", f"{rep['Ausgaben gesamt'].sum():,.2f} €")
    kc5.metric("Ich bekomme noch", f"{bottom.get('Ich bekomme noch',0.0):,.2f} €")

    bio = export_excel(rep, bottom, month, year)
    st.download_button("📥 Export Excel (wie dein Template)", data=bio, file_name=f"BFD_Wochenabrechnung_{year}_{month:02d}.xlsx", mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
